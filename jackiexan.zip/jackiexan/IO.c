#include "MKL25Z4.h"
#include "IO.h"

void Pin_OutputMode(int port, int pin)
{
	uint32_t val = (1UL << pin);
	
	switch(port)
	{
		case PORT_A:
		GPIOA_BASE_PTR->PDDR |= val;
		break;
		
		case PORT_B:
		GPIOB_BASE_PTR->PDDR |= val;
		break;
		
		case PORT_C:
		GPIOC_BASE_PTR->PDDR |= val;
		break;
		
		case PORT_D:
		GPIOD_BASE_PTR->PDDR |= val;
		break;
		
		case PORT_E:
		GPIOE_BASE_PTR->PDDR |= val;
		break;
	}
}

void Pin_Set(int port, int pin){
	
	uint32_t val = (1UL << pin);
	
	switch(port)
	{
		case PORT_A:
			GPIOA_BASE_PTR->PSOR |= val;
			break;
		
		case PORT_B:
			GPIOB_BASE_PTR->PSOR |= val;
			break;
		
		case PORT_C:
			GPIOC_BASE_PTR->PSOR |= val;
			break;
		
		case PORT_D:
			GPIOD_BASE_PTR->PSOR |= val;
			break;
		
		case PORT_E:
			GPIOE_BASE_PTR->PSOR |= val;
			break;
	}
	
}

void Pin_Clear(int port, int pin){
	
	uint32_t val = (1UL << pin);
	
	switch(port)
	{
		case PORT_A:
			GPIOA_BASE_PTR->PCOR |= val;
			break;
		
		case PORT_B:
			GPIOB_BASE_PTR->PCOR |= val;
			break;
		
		case PORT_C:
			GPIOC_BASE_PTR->PCOR |= val;
			break;
		
		case PORT_D:
			GPIOD_BASE_PTR->PCOR |= val;
			break;
		
		case PORT_E:
			GPIOE_BASE_PTR->PCOR |= val;
			break;
	} 
}