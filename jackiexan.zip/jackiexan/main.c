#include "MKL25Z4.h"

#include "IO.h"

int main(void) {
  /*Habilita o clock para os PORTS*/
  ENABLE_PORTS(PORT_B);
  ENABLE_PORTS(PORT_C);
  ENABLE_PORTS(PORT_D);

  /*Configura a fun��o do pino PTB18 como I/O - Vermelho*/
  SetPinMode(PORT_B, 18);

  /*Configura a fun��o do pino PTB19 como I/O - Verde*/
  SetPinMode(PORT_B, 19);

  /*Configura a fun��o do pino PTC13 e PTC17 como I/O - Bot�es*/
  SetPinMode(PORT_C, 13);
  SetPinMode(PORT_C, 17);

  /*Configura a fun��o do pino PTB18 como I/O - Azul*/
  SetPinMode(PORT_D, 1);

  /*Configura a dire��o do pino PTB18 como sa�da - Vermelho*/
  Pin_OutputMode(PORT_B, 18);

  /*Configura a dire��o do pino PTB19 como sa�da - Verde*/
  Pin_OutputMode(PORT_B, 19);

  /*Configura a dire��o do pino PTD1 como sa�da - Azul*/
  Pin_OutputMode(PORT_D, 1);

  while (1) {
    if (GetPinValue(PORT_C, 13)) {
      for (int a = 0; a < 100000; a++) {
        Pin_Clear(PORT_B, 18);
        Pin_Set(PORT_B, 18);
      }

      for (int a = 0; a < 100000; a++) {

        Pin_Clear(PORT_B, 19);
        Pin_Set(PORT_B, 19);

      }

      for (int a = 0; a < 100000; a++) {

        Pin_Clear(PORT_D, 1);
        Pin_Set(PORT_D, 1);

      }

      for (int a = 0; a < 100000; a++) {
        Pin_Clear(PORT_B, 19);
        Pin_Clear(PORT_D, 1);
        Pin_Set(PORT_B, 19);
        Pin_Set(PORT_D, 1);

      }

      for (int a = 0; a < 100000; a++) {
        Pin_Clear(PORT_B, 18);
        Pin_Clear(PORT_D, 1);
        Pin_Set(PORT_B, 18);
        Pin_Set(PORT_D, 1);

      }

      for (int a = 0; a < 100000; a++) {
        Pin_Clear(PORT_B, 18);
        Pin_Clear(PORT_B, 19);
        Pin_Clear(PORT_D, 1);
        Pin_Set(PORT_B, 18);
        Pin_Set(PORT_B, 19);
        Pin_Set(PORT_D, 1);

      }
    }

  }

  return 0;
}