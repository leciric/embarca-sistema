#include "MKL25Z4.h"
#include "IO.h"

int main(void)
{
	/*Habilita o clock para o PORTB e PORTD*/
	SIM_BASE_PTR->SCGC5 = (1<<10) | (1<<12);
	
	/*Configura a fun��o do pino PTB18 como I/O - Vermelho*/
	PORTB_BASE_PTR->PCR[18] = (1<<8);
	
	/*Configura a fun��o do pino PTB18 como I/O - Verde*/
	PORTB_BASE_PTR->PCR[19] = (1<<8);
	
	/*Configura a fun��o do pino PTB18 como I/O - Azul*/
	PORTD_BASE_PTR->PCR[1] = (1<<8);
	
	
	/*Configura a dire��o do pino PTB18 como sa�da - Vermelho*/
	Pin_OutputMode(PORT_B,18);
	
	/*Configura a dire��o do pino PTB19 como sa�da - Verde*/
	Pin_OutputMode(PORT_B,19);
	
	/*Configura a dire��o do pino PTD1 como sa�da - Azul*/
	Pin_OutputMode(PORT_D,1);
	
	while(1){
		
		for(int a=0;a<100000;a++)
		{
			Pin_Clear(PORT_B,18);
			Pin_Set(PORT_B,18);
		}
		
		for(int a=0; a<100000; a++)
		{

			Pin_Clear(PORT_B,19);
			Pin_Set(PORT_B,19);
				
		}
		
		for(int a=0; a<100000; a++)
		{

			Pin_Clear(PORT_D,1);
			Pin_Set(PORT_D,1);
				
		}
	
		for(int a=0; a<100000; a++)
		{
			Pin_Clear(PORT_B,19);
			Pin_Clear(PORT_D,1);
			Pin_Set(PORT_B,19);
			Pin_Set(PORT_D,1);
				
		}
		
		for(int a=0; a<100000; a++)
		{
			Pin_Clear(PORT_B,18);
			Pin_Clear(PORT_D,1);
			Pin_Set(PORT_B,18);
			Pin_Set(PORT_D,1);
				
		}
		
		for(int a=0; a<100000; a++)
		{
			Pin_Clear(PORT_B,18);
			Pin_Clear(PORT_B,19);
			Pin_Clear(PORT_D,1);
			Pin_Set(PORT_B,18);
			Pin_Set(PORT_B,19);
			Pin_Set(PORT_D,1);
				
		}
	}
	
	
	return 0;
}