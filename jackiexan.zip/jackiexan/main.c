#include "MKL25Z4.h"

#include "IO.h"

int main(void) {
	
	MCG_BASE_PTR->C4 |= MCG_C4_DMX32_MASK;

  ENABLE_PORTS(PORT_B);
  ENABLE_PORTS(PORT_E);

  SetPinMode(PORT_B, 8);
	SetPinMode(PORT_B, 9);
	SetPinMode(PORT_B, 10);
	SetPinMode(PORT_B, 11);

	SetPinMode(PORT_E, 2);
	SetPinMode(PORT_E, 3);
	SetPinMode(PORT_E, 4);
	SetPinMode(PORT_E, 5);
	
	Pin_OutputMode(PORT_B, 8);
	Pin_OutputMode(PORT_B, 9);
	Pin_OutputMode(PORT_B, 10);
	Pin_OutputMode(PORT_B, 11);

  while (1) {
    if (GetPinValue(PORT_E, 2)) {
      Pin_Set(PORT_B,8);

		} else {
			Pin_Clear(PORT_B,8);
		}
		
		if (GetPinValue(PORT_E, 3)) {
      Pin_Set(PORT_B,9);
		}else {
			Pin_Clear(PORT_B,9);
		}
		
		if (GetPinValue(PORT_E, 4)) {
      Pin_Set(PORT_B,10);
		} else {
			Pin_Clear(PORT_B,10);
		}
		
		if (GetPinValue(PORT_E, 5)) {
      Pin_Set(PORT_B,11);
		} else {
			Pin_Clear(PORT_B,11);
		}
  }

  return 0;
}